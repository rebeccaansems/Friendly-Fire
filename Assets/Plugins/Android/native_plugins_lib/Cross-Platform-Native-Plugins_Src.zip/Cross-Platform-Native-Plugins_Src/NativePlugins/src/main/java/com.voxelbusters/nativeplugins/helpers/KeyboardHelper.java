package com.voxelbusters.nativeplugins.helpers;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowManager;

import com.voxelbusters.nativeplugins.helpers.interfaces.IKeyboardListener;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.MiscUtilities;

import java.util.ArrayList;

/**
 * Created by ayyappa on 02/12/17.
 */

public class KeyboardHelper
{
    ArrayList<IKeyboardListener> listeners;
    final float KEYBOARD_VISIBLE_THRESHOLD_IN_DP = 100;

    ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener;

    public KeyboardHelper(Activity rootActivity)
    {
        listeners = new ArrayList<IKeyboardListener>();

        int softInputMode = rootActivity.getWindow().getAttributes().softInputMode;
        if(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE != softInputMode &&
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED != softInputMode)
        {
            Debug.warning("KeyboardHelper", "Need to set ADJUST_RESIZE to get the callbacks");
        }

        registerViewObserver(rootActivity);
    }


    public void addListener(IKeyboardListener listener)
    {
        if(!listeners.contains(listener))
            listeners.add(listener);
    }

    public void removeListener(IKeyboardListener listener)
    {
        if(!listeners.contains(listener))
            listeners.remove(listener);
    }


    private void registerViewObserver(final Activity rootActivity)
    {

        final View rootView = ((ViewGroup) rootActivity.findViewById(android.R.id.content)).getChildAt(0);

        onGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener()
        {
            private final Rect rect = new Rect();
            private boolean oldVisibilityState = false;
            private final int visibleThreshold = MiscUtilities.convertDpToPixels(rootActivity, KEYBOARD_VISIBLE_THRESHOLD_IN_DP);

            @Override
            public void onGlobalLayout()
            {
                rootView.getWindowVisibleDisplayFrame(rect);
                int heightDiff = rootView.getRootView().getHeight() - rect.height();

                boolean isVisible = heightDiff > visibleThreshold;

                if (isVisible != oldVisibilityState)
                {
                    notifyListeners(isVisible);
                    oldVisibilityState = isVisible;
                }
            }
        };

        rootView.getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);
    }

    private void notifyListeners(boolean isVisible)
    {
        for(int i=0;i< listeners.size();i++)
        {
            listeners.get(i).onKeyboardVisibilityChange(isVisible);
        }
    }
}
